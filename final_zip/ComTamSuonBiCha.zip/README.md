# Financial NLP: Stance & Sentiment Classification

COMP6713 2026 T1 — Group Project

## Overview

This project addresses two financial NLP classification tasks:

1. **Stance Classification**: Classifying FOMC (Federal Reserve) communications as *hawkish*, *dovish*, or *neutral* based on implied monetary policy position.
2. **Sentiment Classification**: Classifying financial news sentences as *positive*, *negative*, or *neutral* in terms of market sentiment.

## Setup

```bash
# Create virtual environment (requires Python 3.12)
/opt/homebrew/bin/python3.12 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

## Project Structure

```
.
├── config.py                 # Central configuration (hyperparameters, paths, labels)
├── src/
│   ├── data_loader.py        # Dataset loading (FOMC + Financial PhraseBank)
│   ├── baseline.py           # TF-IDF + Logistic Regression baseline
│   ├── lexicon.py            # Loughran-McDonald lexicon-based classification
│   ├── pretrained_eval.py    # Zero-shot and few-shot evaluation
│   ├── finetune.py           # Single-task FinBERT fine-tuning
│   ├── multitask.py          # Multi-task model (shared encoder + dual heads)
│   └── evaluate.py           # Metrics, confusion matrices, error analysis
├── run_experiments.py        # Main experiment runner
├── cli.py                    # Command-line inference interface
├── demo.py                   # Gradio web demo
├── requirements.txt          # Python dependencies
├── models/                   # Saved trained models
└── results/                  # Evaluation results and plots
```

## Running Experiments

```bash
# Run all experiments end-to-end
python run_experiments.py

# Or run individual steps:
python run_experiments.py --step 2   # Baseline (TF-IDF + LR)
python run_experiments.py --step 3   # Pre-trained model evaluation
python run_experiments.py --step 4   # FinBERT fine-tuning
python run_experiments.py --step 5   # Multi-task training
python run_experiments.py --step 6   # BERT fine-tuning 
```

## Datasets & Lexicon

| Dataset | Source | Labels | Size |
|---------|--------|--------|------|
| FOMC Hawkish-Dovish | [gtfintechlab/fomc_communication](https://huggingface.co/datasets/gtfintechlab/fomc_communication) | hawkish, dovish, neutral | 2,480 |
| Financial PhraseBank | [gtfintechlab/financial_phrasebank_sentences_allagree](https://huggingface.co/datasets/gtfintechlab/financial_phrasebank_sentences_allagree) | positive, negative, neutral | 2,264 |
| LM Lexicon | Loughran & McDonald (2011) Financial Sentiment Dictionary | positive, negative, uncertainty + hawkish/dovish | ~2,700 words |

## Models

| Model | Description |
|-------|-------------|
| TF-IDF + LR | TF-IDF features + Logistic Regression |
| TF-IDF + SVM | TF-IDF features + Support Vector Machine |
| TF-IDF trigram + LR | Trigram TF-IDF features + Logistic Regression |
| TF-IDF trigram + SVM | Trigram TF-IDF features + Support Vector Machine |
| TF-IDF + MNB | TF-IDF features + Multinomial Naive Bayes |
| TF-IDF + CNB | TF-IDF features + Complement Naive Bayes |
| GloVe + LR | GloVe word embeddings + Logistic Regression |
| GloVe + SVM | GloVe word embeddings + Support Vector Machine |
| LM Lexicon (rule-based) | Rule-based classification using Loughran-McDonald word counts |
| TF-IDF + LM Lexicon | TF-IDF augmented with Loughran-McDonald lexicon features |
| FinBERT (zero-shot) | Zero-shot using ProsusAI/finbert's pre-trained sentiment head |
| FinBERT / BERT / RoBERTa (few-shot) | Linear probe on frozen embeddings with k=16 examples per class |
| FinBERT (fine-tuned) | Full fine-tuning of FinBERT on each dataset separately |
| BERT-base (fine-tuned, LLRD) | BERT-base fine-tuned with layer-wise learning rate decay |
| Multi-task FinBERT | Shared FinBERT encoder + task-specific heads, trained jointly on both datasets |

## Results Summary

| Model | Task | Accuracy | Macro-F1 |
|-------|------|----------|----------|
| LM Lexicon (rule-based) | Stance | 0.4153 | 0.3885 |
| LM Lexicon (rule-based) | Sentiment | 0.6932 | 0.5315 |
| TF-IDF + MNB | Stance | 0.5081 | 0.2586 |
| TF-IDF + MNB | Sentiment | 0.7704 | 0.5742 |
| TF-IDF + CNB | Stance | 0.5565 | 0.4322 |
| TF-IDF + CNB | Sentiment | 0.8256 | 0.7262 |
| GloVe + LR | Stance | 0.5161 | 0.5040 |
| GloVe + LR | Sentiment | 0.7903 | 0.7218 |
| GloVe + SVM | Stance | 0.5544 | 0.5225 |
| GloVe + SVM | Sentiment | 0.8035 | 0.7249 |
| TF-IDF + LR | Stance | 0.6089 | 0.5873 |
| TF-IDF + LR | Sentiment | 0.8720 | 0.8232 |
| TF-IDF + SVM | Stance | 0.6331 | 0.6061 |
| TF-IDF + SVM | Sentiment | 0.8940 | 0.8534 |
| TF-IDF trigram + LR | Stance | 0.6109 | 0.5914 |
| TF-IDF trigram + LR | Sentiment | 0.8786 | 0.8310 |
| TF-IDF trigram + SVM | Stance | 0.6008 | 0.5670 |
| TF-IDF trigram + SVM | Sentiment | 0.8808 | 0.8312 |
| TF-IDF + LM Lexicon | Stance | 0.6109 | 0.5863 |
| TF-IDF + LM Lexicon | Sentiment | 0.8543 | 0.8050 |
| FinBERT (zero-shot) | Stance | 0.4980 | 0.4874 |
| FinBERT (zero-shot) | Sentiment | 0.9735 | 0.9650 |
| FinBERT few-shot (k=16) | Stance | 0.4859 | 0.4552 |
| FinBERT few-shot (k=16) | Sentiment | 0.9801 | 0.9690 |
| BERT-base few-shot (k=16) | Stance | 0.3790 | 0.3694 |
| BERT-base few-shot (k=16) | Sentiment | 0.7461 | 0.6599 |
| RoBERTa-base few-shot (k=16) | Stance | 0.3589 | 0.3489 |
| RoBERTa-base few-shot (k=16) | Sentiment | 0.7572 | 0.6439 |
| FinBERT fine-tuned | Stance | 0.6129 | 0.5988 |
| FinBERT fine-tuned | Sentiment | 0.9669 | 0.9467 |
| BERT-base fine-tuned (LLRD) | Stance | 0.6512 | 0.6371 |
| BERT-base fine-tuned (LLRD) | Sentiment | 0.9691 | 0.9533 |
| **Multi-task FinBERT** | **Stance** | **0.6774** | **0.6684** |
| **Multi-task FinBERT** | **Sentiment** | **0.9845** | **0.9772** |

## CLI Usage

```bash
# Interactive mode
python cli.py

# Single sentence
python cli.py --text "The Fed signaled further rate hikes ahead"

# From file
python cli.py --file input.txt

# Use fine-tuned (single-task) models instead of multi-task
python cli.py --model finetune --text "Markets rallied on dovish comments"
```

## Gradio Demo

```bash
python demo.py
# Opens at http://localhost:7860
```

## Trained Models on HuggingFace

Pre-trained model weights are hosted on HuggingFace Hub:

**[Louisnguyen/financial-nlp-stance-sentiment](https://huggingface.co/collections/Louisnguyen/nlp)**
