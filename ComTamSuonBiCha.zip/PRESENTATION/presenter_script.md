# Presentation Script (5-7 minutes + Q&A)
## COMP6713 2026 T1
## Team: Louis Nguyen, Quoc Dat Bui, Nam Khanh Tran, Quang Minh Phan

---

## SLIDE 1: Title (~20 seconds)

> Hi, we are [names]. Our project is Financial NLP: Stance and Sentiment Classification.

---

## SLIDE 2: Problem + Datasets (~1 minute)

> We tackle two tasks. **Stance classification**: classifying FOMC central bank sentences as hawkish, dovish, or neutral. **Sentiment classification**: classifying financial news as positive, negative, or neutral.
>
> We use the FOMC Hawkish-Dovish dataset (2,480 sentences, imbalanced with 49% neutral) and Financial PhraseBank (2,264 sentences, 100% annotator agreement). We also use the Loughran-McDonald financial lexicon. All split 70/10/20 stratified.

---

## SLIDE 3: Data Analysis (~40 seconds)

> Key data findings: FOMC is class-imbalanced, sentences are longer (avg 30 words vs 22), and hawkish words overlap heavily with neutral sentences, which is why lexicon rules only achieve 41% on stance.

---

## SLIDE 4: Modelling Pipeline (~40 seconds)

> We follow a progression: TF-IDF baselines, then pre-trained transformers zero-shot and few-shot, then fine-tuning, and finally our extended method: multi-task learning.

---

## SLIDE 5: Key Result: Domain Pre-training (~1 minute)

> The biggest finding: domain-specific pre-training is transformative. FinBERT few-shot achieves 98% on sentiment versus just 74% for BERT-base. On stance, all few-shot models struggle below 49%, confirming that stance requires fine-tuning.

---

## SLIDE 6: Multi-task Learning (~1 minute)

> Our best model is multi-task FinBERT: shared encoder with dual task heads, alternating batches, weighted cross-entropy for FOMC imbalance. It achieves **98.45% sentiment** and **67.74% stance**, the best across all 14 configurations. Multi-task improves stance by +6.5pp over single-task FinBERT.

---

## SLIDE 7: Results + Analysis (~1 minute)

> [Show results table] Multi-task wins both tasks. The sentiment-stance gap persists across all models, reflecting fundamental task difficulty. Error analysis shows neutral-hawkish confusion is the main challenge: subtle policy language that even humans find ambiguous.

---

## SLIDE 8: Demo (~30 seconds, optional live demo)

> We provide a Gradio web interface and CLI for testing. [If live demo: show a sentence being classified in real time.]

---

## SLIDE 9: Conclusion (~20 seconds)

> Multi-task FinBERT with shared encoder achieves state-of-the-art on both tasks. Domain pre-training is essential. Future work: more FOMC data and larger models. Thank you, happy to take questions.

---

## Q&A Prep

**Q: Why not GPT-4/LLMs?**
> We focused on encoder models for fast inference. LLMs could be future work but add latency and cost.

**Q: How do you handle class imbalance?**
> Inverse-frequency weighted cross-entropy for stance. Multi-task also helps through cross-task regularization.

**Q: Why is stance so much harder?**
> Subtle policy language, class imbalance, longer sentences. Hawkish/dovish signals are context-dependent unlike sentiment which has clear lexical cues.

**Q: Could you improve stance further?**
> More training data, document-level context, economic indicator features, model ensembling.

**Q: Why multi-task over separate models?**
> Shared encoder learns richer representations, implicit regularization, and halves inference cost.
