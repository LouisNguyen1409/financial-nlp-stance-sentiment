# Team Contribution

## Team Members

| Name | zID | Contribution |
|------|-----|-------------|
| Louis Nguyen | z5428797 | Multi-task learning architecture, fine-tuning (FinBERT, BERT LLRD), CLI interface, Gradio demo, HuggingFace deployment, project lead |
| Quoc Dat Bui | z5404752 | Data loading and preprocessing, baseline models (TF-IDF + LR/SVM), alternative baselines, data analysis and visualization |
| Nam Khanh Tran | z5577208 | Pre-trained model evaluation (zero-shot, few-shot), Loughran-McDonald lexicon implementation, error analysis |
| Quang Minh Phan | z5531827 | Evaluation framework, confusion matrices, report writing, presentation slides, documentation |

## Contribution Summary

All team members contributed equally to the project. Each member was responsible for specific components as outlined above, and all members participated in code review, testing, and the final presentation.

## Peer Evaluation

All members agree that contributions were equal (25% each).
